package hr.fer.zemris.java.gui.calc.model.components;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.CalcValueListener;

public class CalcDisplay extends JLabel implements CalcValueListener {
	private static final long serialVersionUID = 8782454292120908970L;

	public CalcDisplay(Dimension size) {
		setOpaque(true);
		setBorder(BorderFactory.createEtchedBorder());
		setBackground(Color.YELLOW);
		setHorizontalAlignment(SwingConstants.RIGHT);
		setFont(new Font(getFont().toString(), getFont().getStyle(), (int) size.getHeight() / 10));
		setText("0");
	}

	@Override
	public void valueChanged(CalcModel model) {
		setText(model.toString());
	}

}
