package hr.fer.zemris.java.gui.calc.model.components;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.CalculatorInputException;

public class CalcNumberButton extends JButton {
	private static final long serialVersionUID = 2591383496332374112L;

	public CalcNumberButton(int buttonDigit, CalcModel calc) {
		super(Integer.toString(buttonDigit));

		this.addActionListener(a -> {
			try {
				calc.insertDigit(buttonDigit);
			} catch (CalculatorInputException e) {
				calc.clear();
				calc.insertDigit(buttonDigit);
			}
		});
	}

}
