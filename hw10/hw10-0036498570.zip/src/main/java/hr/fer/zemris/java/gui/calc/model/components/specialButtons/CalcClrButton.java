package hr.fer.zemris.java.gui.calc.model.components.specialButtons;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.components.CalcSpecialButton;

public class CalcClrButton extends JButton implements CalcSpecialButton {
	private static final long serialVersionUID = -3568067204276598207L;

	public CalcClrButton(CalcModel calc) {
		super("clr");
		addAction(calc);
	}

	@Override
	public void addAction(CalcModel calc) {
		this.addActionListener(a -> {
			calc.clear();
		});
	}

}
