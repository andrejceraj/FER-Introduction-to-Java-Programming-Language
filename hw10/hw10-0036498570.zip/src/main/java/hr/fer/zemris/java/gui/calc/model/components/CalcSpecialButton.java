package hr.fer.zemris.java.gui.calc.model.components;

import hr.fer.zemris.java.gui.calc.model.CalcModel;

public interface CalcSpecialButton {
	void addAction(CalcModel calc);
}
