package hr.fer.zemris.java.gui.calc.model.components.specialButtons;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.components.CalcSpecialButton;

public class CalcResetButton extends JButton implements CalcSpecialButton {
	private static final long serialVersionUID = 2399808259740624289L;

	public CalcResetButton(CalcModel calc) {
		super("reset");
		addAction(calc);
	}

	@Override
	public void addAction(CalcModel calc) {
		this.addActionListener(a -> {
			calc.clearAll();
		});
	}

}
