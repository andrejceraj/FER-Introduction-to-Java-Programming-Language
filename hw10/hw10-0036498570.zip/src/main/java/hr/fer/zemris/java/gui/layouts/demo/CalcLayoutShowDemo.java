package hr.fer.zemris.java.gui.layouts.demo;

import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import hr.fer.zemris.java.gui.layouts.CalcLayout;
import hr.fer.zemris.java.gui.layouts.RCPosition;

public class CalcLayoutShowDemo {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			JFrame frame = new TestCalcLayout();
			frame.setVisible(true);
		});
	}

	private static class TestCalcLayout extends JFrame {
		private static final long serialVersionUID = 1L;

		public TestCalcLayout() {
			setLocation(20, 50);
			setSize(300, 200);
			setTitle("Moj prvi prozor!");
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			initGUI2();
		}

		private void initGUI1() {
			Container p = getContentPane();
			p.setLayout(new CalcLayout(3));
			p.add(new JLabel("(1,1)"), new RCPosition(1, 1));
			p.add(new JLabel("(2,3)"), new RCPosition(2, 3));
			p.add(new JLabel("(2,7)"), new RCPosition(2, 7));
			p.add(new JLabel("(4,2)"), new RCPosition(4, 2));
			p.add(new JLabel("(4,5)"), new RCPosition(4, 5));
			p.add(new JLabel("(4,7)"), new RCPosition(4, 7));
			p.setVisible(true);
		}

		private void initGUI2() {
			Container p = getContentPane();
			p.setLayout(new CalcLayout(3));
			p.add(new JLabel("1,1"), "1,1");
			p.add(new JLabel("2,3"), "2,3");
			p.add(new JLabel("2,7"), "2,7");
			p.add(new JLabel("4,2"), "4,2");
			p.add(new JLabel("4,5"), "4,5");
			p.add(new JLabel("4,7"), "4,7");
			p.setVisible(true);
		}

		private void initGUI3() {
			Container p = getContentPane();
			p.setLayout(new CalcLayout(3));
			p.add(new JButton("x"), new RCPosition(1, 1));
			p.add(new JButton("y"), new RCPosition(2, 3));
			p.add(new JButton("z"), new RCPosition(2, 7));
			p.add(new JButton("w"), new RCPosition(4, 2));
			p.add(new JButton("a"), new RCPosition(4, 5));
			p.add(new JButton("b"), new RCPosition(4, 7));
			p.setVisible(true);

		}

	}

}
