package hr.fer.zemris.java.gui.calc.model.components;

import java.util.function.DoubleBinaryOperator;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;

public class CalcPowerButton extends JButton {
	private static final long serialVersionUID = 3533422062438935988L;
	private String buttonText;
	private String buttonTextReversed;

	public CalcPowerButton(String buttonText, String buttonTextReversed, DoubleBinaryOperator operator,
			DoubleBinaryOperator operatorReversed, CalcModel calc) {
		super(buttonText);
		this.buttonText = buttonText;
		this.buttonTextReversed = buttonTextReversed;
		this.addActionListener(a -> {
			if (calc.getPendingBinaryOperation() != null && calc.isActiveOperandSet()) {
				double midResult = calc.getPendingBinaryOperation().applyAsDouble(calc.getActiveOperand(),
						calc.getValue());
				calc.setActiveOperand(midResult);
			} else {
				calc.setActiveOperand(calc.getValue());
			}
			calc.setPendingBinaryOperation(CalcUnaryOperationButton.isReversed ? operatorReversed : operator);
			calc.setValue(calc.getActiveOperand());
		});
	}

	public void update() {
		setText(CalcUnaryOperationButton.isReversed ? buttonTextReversed : buttonText);
	}
}
