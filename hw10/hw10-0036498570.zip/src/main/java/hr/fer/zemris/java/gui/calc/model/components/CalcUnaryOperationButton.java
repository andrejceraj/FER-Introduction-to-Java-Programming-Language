package hr.fer.zemris.java.gui.calc.model.components;

import java.util.function.DoubleUnaryOperator;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;

public class CalcUnaryOperationButton extends JButton {
	private static final long serialVersionUID = 8159466545205051675L;
	public static boolean isReversed = false;

	private String buttonText;
	private String buttonTextReversed;

	public CalcUnaryOperationButton(String buttonText, String buttonTextReversed, DoubleUnaryOperator operator,
			DoubleUnaryOperator operatorReversed, CalcModel calc) {
		super(buttonText);
		this.buttonText = buttonText;
		this.buttonTextReversed = buttonTextReversed;
		this.addActionListener(a -> {
			double result;
			if (!isReversed)
				result = operator.applyAsDouble(calc.getValue());
			else
				result = operatorReversed.applyAsDouble(calc.getValue());
			calc.setValue(result);
		});
	}

	public void update() {
		setText(isReversed ? buttonTextReversed : buttonText);
	}

}
