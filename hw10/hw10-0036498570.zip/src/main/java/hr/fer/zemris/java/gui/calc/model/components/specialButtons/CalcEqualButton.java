package hr.fer.zemris.java.gui.calc.model.components.specialButtons;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.components.CalcSpecialButton;

public class CalcEqualButton extends JButton implements CalcSpecialButton {
	private static final long serialVersionUID = -6525199962327011713L;

	public CalcEqualButton(CalcModel calc) {
		super("=");
		addAction(calc);
	}

	@Override
	public void addAction(CalcModel calc) {
		this.addActionListener(a -> {
			if (calc.getPendingBinaryOperation() != null && calc.isActiveOperandSet()) {
				double result = calc.getPendingBinaryOperation().applyAsDouble(calc.getActiveOperand(),
						calc.getValue());
				calc.setValue(result);
				calc.clearActiveOperand();
			}
		});
	}

}
