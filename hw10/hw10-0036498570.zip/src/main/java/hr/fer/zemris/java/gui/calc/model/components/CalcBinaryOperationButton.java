package hr.fer.zemris.java.gui.calc.model.components;

import java.util.function.DoubleBinaryOperator;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;

public class CalcBinaryOperationButton extends JButton {
	private static final long serialVersionUID = 8768680462474292849L;

	public CalcBinaryOperationButton(String buttonText, DoubleBinaryOperator operator, CalcModel calc) {
		super(buttonText);

		this.addActionListener(a -> {
			if (calc.getPendingBinaryOperation() != null && calc.isActiveOperandSet()) {
				double midResult = calc.getPendingBinaryOperation().applyAsDouble(calc.getActiveOperand(),
						calc.getValue());
				calc.setActiveOperand(midResult);
			} else {
				calc.setActiveOperand(calc.getValue());
			}
			calc.setPendingBinaryOperation(operator);
			calc.setValue(calc.getActiveOperand());
		});
	}

}
