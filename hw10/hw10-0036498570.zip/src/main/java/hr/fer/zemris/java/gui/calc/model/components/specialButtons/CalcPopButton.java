package hr.fer.zemris.java.gui.calc.model.components.specialButtons;

import java.util.Stack;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.components.CalcSpecialButton;

public class CalcPopButton extends JButton implements CalcSpecialButton {
	private static final long serialVersionUID = 7406950501625818120L;
	private Stack<Double> stack;

	public CalcPopButton(Stack<Double> stack, CalcModel calc) {
		super("pop");
		this.stack = stack;
		addAction(calc);
	}

	@Override
	public void addAction(CalcModel calc) {
		this.addActionListener(a -> {
			calc.setValue(stack.pop());
		});

	}

}
