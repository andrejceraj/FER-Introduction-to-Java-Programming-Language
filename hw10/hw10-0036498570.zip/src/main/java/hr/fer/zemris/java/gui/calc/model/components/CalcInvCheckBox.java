package hr.fer.zemris.java.gui.calc.model.components;

import java.util.List;

import javax.swing.JCheckBox;

import hr.fer.zemris.java.gui.calc.model.CalcModel;

public class CalcInvCheckBox extends JCheckBox {
	private static final long serialVersionUID = 6864146276324867313L;

	public CalcInvCheckBox(List<CalcUnaryOperationButton> unaryOperationButtons, CalcPowerButton power,
			CalcModel calc) {
		super("inv");

		this.addActionListener(a -> {
			CalcUnaryOperationButton.isReversed = !CalcUnaryOperationButton.isReversed;
			unaryOperationButtons.forEach(u -> u.update());
			power.update();
		});
	}

}
