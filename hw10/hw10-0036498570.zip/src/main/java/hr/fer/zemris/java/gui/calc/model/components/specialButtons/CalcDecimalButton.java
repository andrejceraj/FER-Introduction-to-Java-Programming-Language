package hr.fer.zemris.java.gui.calc.model.components.specialButtons;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.CalculatorInputException;
import hr.fer.zemris.java.gui.calc.model.components.CalcSpecialButton;

public class CalcDecimalButton extends JButton implements CalcSpecialButton {
	private static final long serialVersionUID = -5691463894777057284L;

	public CalcDecimalButton(CalcModel calc) {
		super(".");
		addAction(calc);
	}

	@Override
	public void addAction(CalcModel calc) {
		this.addActionListener(a -> {
			try {
				calc.insertDecimalPoint();
			} catch (CalculatorInputException e) {

			}
		});
	}

}
