package hr.fer.zemris.java.gui.calc.model.components.specialButtons;

import javax.swing.JButton;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.components.CalcSpecialButton;

public class CalcSwapSignButton extends JButton implements CalcSpecialButton {
	private static final long serialVersionUID = 2897190679741405803L;

	public CalcSwapSignButton(CalcModel calc) {
		super("+/-");
		addAction(calc);
	}

	@Override
	public void addAction(CalcModel calc) {
		this.addActionListener(a -> {
			try {
				calc.swapSign();
			} catch (Exception e) {
			}
		});

	}

}
