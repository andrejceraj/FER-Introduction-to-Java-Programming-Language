package hr.fer.zemris.java.gui.prim;

import java.util.ArrayList;
import java.util.List;

import javax.swing.ListModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

public class PrimListModel implements ListModel<Integer> {
	private List<Integer> primeNumbers;
	private List<ListDataListener> dataListeners;

	public PrimListModel() {
		primeNumbers = new ArrayList<Integer>();
		dataListeners = new ArrayList<ListDataListener>();
		primeNumbers.add(1);
	}

	@Override
	public void addListDataListener(ListDataListener l) {
		dataListeners.add(l);
	}

	@Override
	public Integer getElementAt(int index) {
		return primeNumbers.get(index);
	}

	@Override
	public int getSize() {
		return primeNumbers.size();
	}

	@Override
	public void removeListDataListener(ListDataListener l) {
		dataListeners.remove(l);
	}

	public void next() {
		int lastPrime = primeNumbers.get(primeNumbers.size() - 1);
		while (true) {
			lastPrime++;
			if (isPrime(lastPrime)) {
				primeNumbers.add(lastPrime);
				break;
			}
		}
		notifyListeners();
	}

	private boolean isPrime(int lastPrime) {
		if (lastPrime == 2) {
			return true;
		}
		for (int i = 2; i * i <= lastPrime; i++) {
			if (lastPrime % i == 0) {
				return false;
			}
		}
		return true;
	}

	private void notifyListeners() {
		ListDataEvent event = new ListDataEvent(this, ListDataEvent.INTERVAL_ADDED, primeNumbers.size() - 1,
				primeNumbers.size());
		dataListeners.forEach(a -> a.intervalAdded(event));
	}
}
