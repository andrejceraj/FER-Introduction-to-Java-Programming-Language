/**
 * Package contains third problem of 6th homework of Basics of Java Programming
 * Language
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.hw06.shell;