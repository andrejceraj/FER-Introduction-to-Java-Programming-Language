/**
 * 
 */
/**
 * @author cerko
 *
 */
package hr.fer.zemris.java.custom.collections;