/**
 * 
 */
/**
 * @author cerko
 *
 */
package hr.fer.zemris.java.hw02;