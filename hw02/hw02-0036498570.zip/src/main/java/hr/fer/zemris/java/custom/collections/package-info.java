/**
 * Package for custom made collections used in second homework of the Basics of
 * Java Programming Language course.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.custom.collections;