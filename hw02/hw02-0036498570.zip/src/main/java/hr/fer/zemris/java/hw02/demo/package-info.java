/**
 * Package in which demonstration of {@link ComplexNumber} is stored.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.hw02.demo;