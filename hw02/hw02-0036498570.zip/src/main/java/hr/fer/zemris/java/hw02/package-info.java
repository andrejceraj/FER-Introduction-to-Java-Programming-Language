/**
 * Package contains Problem 5 from second homework of the Basics of Java
 * Programming Language course.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.hw02;