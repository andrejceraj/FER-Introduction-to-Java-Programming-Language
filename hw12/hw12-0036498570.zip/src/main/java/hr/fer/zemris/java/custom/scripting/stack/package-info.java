/**
 * Package contains all classes required for {@link ObjectStack} to work
 * properly.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.custom.scripting.stack;