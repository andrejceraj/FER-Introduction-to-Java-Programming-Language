/**
 * Package contains types of Elements used in Nodes.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.custom.scripting.elems;