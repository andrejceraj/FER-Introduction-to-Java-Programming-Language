package hr.fer.zemris.java.hw17;

/**
 * Search shell status
 * 
 * @author Andrej Ceraj
 *
 */
public enum Status {
	CONTINUE, TERMINATE;
}
