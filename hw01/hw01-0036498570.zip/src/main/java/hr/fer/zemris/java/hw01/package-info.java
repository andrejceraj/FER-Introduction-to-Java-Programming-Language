/**
 * Package contains program tasks from first homework of the course Basics of
 * Java programing language
 * 
 * @author Andrej Ceraj
 */
package hr.fer.zemris.java.hw01;