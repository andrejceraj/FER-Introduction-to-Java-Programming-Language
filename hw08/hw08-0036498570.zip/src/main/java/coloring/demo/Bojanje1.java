package coloring.demo;

import marcupic.opjj.statespace.coloring.FillApp;

/**
 * Demonstration of {@link FillApp}
 * 
 * @author Andrej Ceraj
 *
 */
public class Bojanje1 {
	/**
	 * Method starts when the program is run.
	 * 
	 * @param args not used
	 */
	public static void main(String[] args) {
		FillApp.run(FillApp.OWL, null); // ili FillApp.ROSE
	}
}
