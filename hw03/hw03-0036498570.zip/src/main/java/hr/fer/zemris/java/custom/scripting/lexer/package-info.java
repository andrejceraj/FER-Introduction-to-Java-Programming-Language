
/**
 * Package contains classes required for {@link Lexer} to work properly
 * 
 * @author Andrej Ceraj
 */
package hr.fer.zemris.java.custom.scripting.lexer;