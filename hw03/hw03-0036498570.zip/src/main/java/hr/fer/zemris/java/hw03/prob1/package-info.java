/**
 * Package containing classes of first problem of third homework in Basics of
 * Java Programming Language course.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.hw03.prob1;