
/**
 * Package for demonstration of classes and interfaces of package
 * hr.fer.java.zemris.custom.collection
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.custom.collections.demo;