
/**
 * Package contains text parser and exception which should be thrown when it is
 * not possible to parse the text.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.custom.scripting.parser;