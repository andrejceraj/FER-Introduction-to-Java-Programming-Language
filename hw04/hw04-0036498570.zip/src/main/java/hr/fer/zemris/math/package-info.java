
/**
 * Package contains third task of fourth homework of Basics of Java Programming
 * Language course. It has implementation of two dimansional vector.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.math;