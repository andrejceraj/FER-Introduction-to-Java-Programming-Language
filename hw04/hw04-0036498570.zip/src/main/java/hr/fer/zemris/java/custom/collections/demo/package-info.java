/**
 * Package contains demonstrations of custom collections.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.custom.collections.demo;