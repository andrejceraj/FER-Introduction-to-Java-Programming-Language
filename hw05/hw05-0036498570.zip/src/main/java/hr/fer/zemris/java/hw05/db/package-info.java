/**
 * Package contains required classes and interfaces to solve task 2 of 5th
 * homework of Basics of Java Programming Language course.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.hw05.db;