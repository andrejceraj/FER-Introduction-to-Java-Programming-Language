
/**
 * Package contains demonstrations of first task of 5th homework of Basics of
 * Java Programming Language course.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.lsystems.impl.demo;