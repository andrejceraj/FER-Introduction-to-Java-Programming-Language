
/**
 * Package contains 2-dimensional vector implementation used in fourth and fifth
 * homework of Basics of Java Programming Language course.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.math;