/**
 * Package for custom made collections created and edited in several homeworks of the
 * Basics of Java Programming Language course.
 * 
 * @author Andrej Ceraj
 *
 */
package hr.fer.zemris.java.custom.collections;