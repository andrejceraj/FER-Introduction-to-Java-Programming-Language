/**
 * Package contains simple lexer used in task 2 of this homework
 * 
 * @author Andrej Ceraj
 * 
 */
package hr.fer.zemris.java.hw05.db.lexer;